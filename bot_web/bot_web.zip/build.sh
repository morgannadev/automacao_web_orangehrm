#!/bin/bash

zip -r "bot_web.zip" * -x "bot_web.zip"